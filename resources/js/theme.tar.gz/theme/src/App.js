import React from 'react';
import logo from './logo.svg';
import './App.css';

// import '../assets/plugins/morris/morris.css';
import '../assets/css/page.min.css';
import '../assets/css/style.css';
// import './assets/css/components.css';
// import './assets/css/icons.css';
// import './assets/css/pages.css';
// import './assets/css/menu.css';
// import './assets/css/responsive.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}

export default App;
