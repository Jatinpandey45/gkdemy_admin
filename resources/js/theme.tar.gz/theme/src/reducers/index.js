import { combineReducers } from 'redux';
import postReducers from './postsReducer';
import categoryListReducers from './categoryListReducers';
import categoryReducers from './categoryReducers';
import monthlyReducers from './monthlyReducers';

export default combineReducers({
    posts: postReducers,
    categories: categoryListReducers,
    monthlyCategories: monthlyReducers,
    category: categoryReducers
});