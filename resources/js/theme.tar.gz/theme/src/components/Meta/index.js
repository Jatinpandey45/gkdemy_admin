// import React from 'react';
// import logo from './logo.svg';
// import './App.css';

// function App() {
//   return (
//     <div className="App">
//       <header className="App-header">
//         <img src={logo} className="App-logo" alt="logo" />
//         <p>
//           Edit <code>src/App.js</code> and save to reload.
//         </p>
//         <a
//           className="App-link"
//           href="https://reactjs.org"
//           target="_blank"
//           rel="noopener noreferrer"
//         >
//           Learn React
//         </a>
//       </header>
//     </div>
//   );
// }

// export default App;


import React, { Component } from 'react';
import { Helmet } from 'react-helmet';


class Meta extends Component {
  render() {
    return (
      <div>
        <Helmet>
            <title>Testing</title>
            <meta name="description" content="Testing" />

            <meta property="og:type" content="post" />
            <meta property="og:title" content="testing title" />
            <meta property="og:url" content="https://currentaffairs.gktoday.in/national-policy-to-speed-up-gas-infrastructure-112019321139.html" />
            <meta property="og:image" content="https://currentaffairs.gktoday.in/wp-content/uploads/2019/11/gas.jpeg" />
            <meta property="article:published_time" content="2019-11-23" />
            <meta property="article:modified_time" content="2019-11-23" />
            <meta property="article:author" content="https://currentaffairs.gktoday.in/author/subbu" />
            <meta property="article:section" content="Governance &amp; Politics" />
            <meta property="article:tag" content="Compressed natural gas" />
            <meta property="article:tag" content="Cooking Gas" />
            <meta property="article:tag" content="LPG" />
            <meta property="article:tag" content="LPG Connections" />
            <meta property="article:tag" content="LPG Reforms" />
            <meta property="article:tag" content="LPG Scheme" />
            <meta property="article:tag" content="Current Affairs - November, 2019" />
            <meta property="article:tag" content="National Current Affairs India" />
            <meta property="og:site_name" content="Current Affairs Today" />
            <meta name="twitter:card" content="summary" />
            <meta name="twitter:creator" content="@gktoday" />
            <meta name="twitter:site" content="@gktoday" />
            <meta name="twitter:creator:id" content="gktoday" />
          {/* <meta name="theme-color" content={this.props} /> */}
        </Helmet>
      </div>
    );
  }
}

export default Meta;