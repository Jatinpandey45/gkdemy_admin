import React from 'react';
// import NavBarUl from './NavBarUl';

class NavListItem extends React.Component
{
    render() {
        return (
            <li className="nav-item">
                <a className="nav-link" href="#">
                    {this.props.listItem}
                    <span className="arrow"></span>
                </a>
            </li>
        );
    }
}

// const mapStateToProps = state => {
//     return { posts : state.props };
// }
// export default connect(mapStateToProps, { fetchPosts })(NavListItem);

export default NavListItem;