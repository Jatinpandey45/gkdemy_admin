import React from 'react';
// import './App.css';

const NavBarLeft = () => {
  return (
    <div className="navbar-left">
      <button className="navbar-toggler" type="button">☰</button>
      <a className="navbar-brand d-none d-stick-block mr-4" href="#">
        GKdemy
      </a>
    </div>
  );
}

export default NavBarLeft;
