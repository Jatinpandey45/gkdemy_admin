import React from 'react';
// import './App.css';
import NavBarUl from './NavBarUl';
import { Link } from 'react-router-dom';


const NavBarMobile = () => {
  return (
    <section className="navbar-mobile">
      <div className="nav nav-navbar mr-auto">
        <Link to="/"  className="nav-link text-white active font-size-14" style={{color: "black"}}>
          Home
        </Link>
        <Link to="/current-affairs"  className="nav-link text-white font-size-14" style={{color: "black"}}>
          Current Affairs
        </Link>
        <Link to="/job-alerts"  className="nav-link text-white font-size-14" style={{color: "black"}}>
          Job Alerts
        </Link>
      </div>

      <nav className="nav nav-navbar ml-lg-5">
        <a className="nav-link lead-3 text-white d-sm-none" href="#" data-toggle="offcanvas" data-target="#offcanvas-menu">☰</a>
      </nav>
    </section>
  );
}

export default NavBarMobile;
