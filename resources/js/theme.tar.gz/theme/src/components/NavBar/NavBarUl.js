import React from 'react';
// import './App.css';
import NavListItem from './NavListItem';

const NavBarUl = () => {
  return (
    <ul className="nav nav-bar">    
        <NavListItem listItem="Home"></NavListItem>
        <NavListItem listItem="Current Affairs"></NavListItem>
        <NavListItem listItem="Job Alerts"></NavListItem>
    </ul>
  );
}

export default NavBarUl;
