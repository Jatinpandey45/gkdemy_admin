import React from 'react';
import NavBarLeft from './navbar-left';
import NavBarMobile from './navbar-mobile';
import NavBarHeader from './NavBarHeader';
// import './App.css';

const Nav = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark flex-column" >
        <NavBarHeader />
        <hr className="my-0 w-100 bg-white"></hr>
        <div className="container">
            <NavBarLeft />
            <NavBarMobile />
        </div>
        {/* <hr class="my-0 w-100 bg-white"></hr> */}
    </nav>
  );
}

export default Nav;
