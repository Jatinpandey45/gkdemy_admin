import React from 'react';
import { Link } from 'react-router-dom';

// import './App.css';

const NavBarHeader = () => {
  return (
    <div className="container d-stick-none">
        <div className="row">
        <div className="col-4">
            {/* <div className="nav nav-navbar">
            <a className="nav-link active" href="#">ENG</a>
            <a className="nav-link" href="#">Hindi</a>
            </div> */}
        </div>

        <div className="col-4 text-center">
            <Link to="/"  className="navbar-brand text-white font-weight-600 lead-5" style={{color: "black"}}>
                GKDemy
            </Link>
            {/* <a className="navbar-brand text-white font-weight-600 lead-5" href="#" style={{color: "black"}}>
            </a> */}
            <h6 className="text-white">India's #1 Current Affairs Website</h6>
        </div>

        <div className="col-4">
            <nav className="nav nav-navbar justify-content-end">
            {/* <a className="nav-link" href="#">
                <i className="fa fa-shopping-cart"></i>
                <span className="badge badge-number badge-danger">4</span>
            </a> */}
            <a className="nav-link text-white" href="#" data-toggle="offcanvas" data-target="#offcanvas-search"><i className="fa fa-search"></i></a>
            </nav>
        </div>

        </div>
    </div>
  );
}

export default NavBarHeader;