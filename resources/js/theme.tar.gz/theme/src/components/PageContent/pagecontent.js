import React from 'react';
import { Router, Route, Switch } from 'react-router-dom';
import HomePage from '../Homepage/homepage';
import Post from '../Posts/post';
import CategoryPost from '../Category/Post';
import MonthlyPost from '../MonthlyPost';
import CurrentAffairs from '../Category/CurrentAffairs';

const PageContent = (props) => {
    return (
        <div>
            {/* <Header /> */}
            <Switch>
                <Route path="/current-affairs/:slug" exact component={Post} />
                <Route path="/current-affairs" exact component={CurrentAffairs} />
                <Route path="/category/:slug" exact component={CategoryPost} />
                <Route path="/monthly-category/:slug" exact component={MonthlyPost} />
                {/* <Route path="/streams/edit/:id" exact component={StreamEdit} />
                <Route path="/streams/delete/:id" exact component={StreamDelete} />
                <Route path="/streams/:id" exact component={StreamShow} /> */}
                <Route path="/" exact component={HomePage} />
            </Switch>
        </div>
    );
};

export default PageContent;