import React from 'react';
import PageItem from './pageItem';

const Pagination = (props) => {
    return (
        <div className="form-group p-5">
            <nav>
                <ul className="pagination justify-content-center">
                    <PageItem name="" link="" firstItem="true" /> 
                    <PageItem name="1" link="" /> 
                    <PageItem name="2" link="" /> 
                    <PageItem name="3" link="" /> 
                    <PageItem name="4" link="" /> 
                    <PageItem name="" link="" lastItem="true" /> 
                </ul>
            </nav>
        </div>
    );
};

export default Pagination;