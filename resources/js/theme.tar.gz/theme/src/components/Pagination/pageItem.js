import React from 'react';

class PageItem extends React.Component {
    renderList() {
        if (typeof this.props.firstItem != 'undefined') {
            return (
                <a className="page-link" href={this.props.link}>
                    <span className="fa fa-angle-left"></span>
                </a>
            );
        } else if (typeof this.props.lastItem != 'undefined') {
            return (
                <a className="page-link" href={this.props.link}>
                    <span className="fa fa-angle-right"></span>
                </a>
            );
        } else {
            return (
                <a className="page-link" href={this.props.link}>
                    {this.props.name}
                </a>
            );
        }
    }

    render() {
        return (
            <li className="page-item">
                {this.renderList()}
            </li>
        );
    }
}

export default PageItem;