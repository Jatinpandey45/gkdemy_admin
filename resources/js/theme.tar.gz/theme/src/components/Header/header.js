import React from 'react';
// import './App.css';

const Header = () => {
  return (
    // <header className="header text-white h-fullscreen overflow-hidden">
    //     <div className="container">
    //       <canvas className="constellation" data-radius="0" width="1366" height="476"></canvas>
    //     </div>
    // </header>

    <section id="over-container" className="section text-white bg-gradient-dark text-white lead pt-8 pb-5">
      <canvas className="constellation" width="1366" height="300"></canvas>

      <div className="container position-static">
        <header className="section-header">
          <small></small>
          {/* <h4>India's #1 Current Affairs Website</h4> */}
          <hr />
          {/* <p className="lead">“Education is the most powerful weapon which you can use to change the world.” ~ Nelson Mandela</p> */}
        </header>


      </div>
    </section>
  );
}

export default Header;
