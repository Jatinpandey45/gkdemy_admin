import React from 'react';
import Category from '../Category/category';
import MonthlyCategory from '../Category/MonthlyCategory';
import PageContent from '../PageContent/pagecontent';
import Pagination from '../Pagination/Pagination';

class Main extends React.Component {
  render() {
    return (
      <main className="main-content">
        <div className="section bg-gray pt-5">
          <div className="container-fluid">
            <div className="row">
              <div className="left-column">
                {/* <Category /> */}
              </div>
              <div className="center-column card">
                <PageContent />
              </div>
              <div className="right-column flex-4">
                <Category heading="Category"/>
                <MonthlyCategory heading="Monthly Category"/>
              </div>
            </div>
          </div>
        </div>
      </main>
    );
  }
}

export default Main;
