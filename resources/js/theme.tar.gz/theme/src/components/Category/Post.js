import React from 'react';
import {connect} from 'react-redux';
import { fetchCategory } from '../../actions';
import PostItem from '../Posts/postitem';

class Post extends React.Component {
    // state = { };
    componentDidMount() {
        this.props.fetchCategory(this.props.match.params.slug);
        this.setState({category: this.props.match.params.slug});
    }

    componentDidUpdate() {
        if (this.state.category !== this.props.match.params.slug) {
            this.props.fetchCategory(this.props.match.params.slug);
            this.setState({category: this.props.match.params.slug});
        }
    }

    renderList() {
        if (!this.props.categoryPosts) {
            return <div>Loading...</div>;
        }
        if (typeof this.props.categoryPosts == 'undefined'
            ||  typeof this.props.categoryPosts.data == 'undefined'
            || this.props.categoryPosts.data.length == 0
        ) {
            return '';
        }

        var categoryPosts = this.props.categoryPosts.data;
        categoryPosts = Array.from(categoryPosts);
        return categoryPosts.map((post) => {
            return (
                <div className="card hover-shadow-3 my-2" key={post.id}>
                    <PostItem post={post.post}/>
                </div>
            );
        });
    }

    render() {
        return (
            <div>
                {this.renderList()}
            </div>
        );
    }
};


const mapStateToProps = state => {
    console.log(state);
    return { categoryPosts : state.category.post, category: state.category.category };
}

export default connect(mapStateToProps, { fetchCategory })(Post);