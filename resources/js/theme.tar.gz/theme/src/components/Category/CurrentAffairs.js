import React from 'react';
import PostList from '../Posts/postlist';
import Post from '../Posts/post';
import { Link } from 'react-router-dom';
import Pagination from '../Pagination/Pagination';


class CurrentAffairs extends React.Component
{
    render() {
        return (
            <div className="row p-5">
                <div className="">
                    <div className="d-flex">
                        <h6 className="sidebar-title font-size-18">Current Affairs</h6>
                    </div>
                    <div className="link-color-default fs-14 lh-24 current-affairs-list">
                        <PostList />
                    </div>
                </div>
                <Pagination />
            </div>
        );
    }
};

export default CurrentAffairs;