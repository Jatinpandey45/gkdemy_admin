import _ from 'lodash';
import React from 'react';
import CategoryList from './categorylist';
import { fetchTag } from '../../actions';
import { connect } from 'react-redux';

class Tag extends React.Component {
    componentDidMount() {
        this.props.fetchCategories();
    }

    renderList() {
        if (typeof this.props.categories ==='undefined'
            || typeof this.props.categories === 'undefined'
        ) {
            return '';
        }
        return this.props.categories.map(category => {
            return (
                <CategoryList category={category} key={category.id} />
            );
        });
    }

    render() {
        return (
            <div className="card form-group p-5">
                <h6 className="sidebar-title font-size-15 mb-1">{this.props.heading}</h6>
                <hr className="my-0 w-100 mb-1"></hr>
                <div className="row link-color-default fs-14 lh-24">
                    {this.renderList()}
                </div>
            </div>
        );
    }
};


const mapStateToProps = (state, ownProps) => {
    return { categories: state.categories };
}

export default connect(
    mapStateToProps,
    { fetchCategories }
)(Category);

// export default Category;