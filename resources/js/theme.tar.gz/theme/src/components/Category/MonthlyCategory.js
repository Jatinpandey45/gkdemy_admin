import _ from 'lodash';
import React from 'react';
import MonthlyCategoryList from './monthlycategorylist';
import { fetchMonthCategories } from '../../actions';
import { connect } from 'react-redux';

class MonthlyCategory extends React.Component {
    componentDidMount() {
        this.props.fetchMonthCategories();
    }

    renderList() {
        if (typeof this.props.monthlyCategories ==='undefined'
            || typeof this.props.monthlyCategories === 'undefined'
        ) {
            return '';
        }
        return this.props.monthlyCategories.map(category => {
            return (
                <MonthlyCategoryList category={category} key={category.id} />
            );
        });
    }

    render() {
        return (
            <div className="card form-group p-5">
                <h6 className="sidebar-title font-size-15 mb-1">{this.props.heading}</h6>
                <hr className="my-0 w-100 mb-1"></hr>
                <div className="row link-color-default fs-14 lh-24">
                    {this.renderList()}
                </div>
            </div>
        );
    }
};


const mapStateToProps = (state, ownProps) => {
    return { monthlyCategories: state.monthlyCategories.data };
}

export default connect(
    mapStateToProps,
    { fetchMonthCategories }
)(MonthlyCategory);

// export default Category;