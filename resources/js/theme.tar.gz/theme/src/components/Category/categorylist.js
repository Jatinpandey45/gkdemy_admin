import React from 'react';
import { Link } from 'react-router-dom';

const CategoryList = ({ category }) => {
    return (
        <div className="col-md-12">
            <Link to={`/category/${category.category_slug}`} >
                {category.category_name}
            </Link>
        </div>
    );
};

export default CategoryList;