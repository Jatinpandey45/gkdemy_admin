import React from 'react';
import { Link } from 'react-router-dom';

const MonthlyCategoryList = ({ category }) => {
    return (
        <div className="col-md-12">
            <Link to={`/monthly-category/${category.month_slug}`}>
                {category.month_name}
            </Link>
        </div>
    );
};

export default MonthlyCategoryList;