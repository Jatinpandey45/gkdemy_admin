import _ from 'lodash';
import React from 'react';
import { connect } from 'react-redux';
import { fetchPost } from '../../actions';
import { Link } from 'react-router-dom';
import Tag from './tag';
import Category from './category';
import Meta from '../Meta';
import Parser from 'html-react-parser';

class Post extends React.Component {
    componentDidMount() {
        this.props.fetchPost(this.props.match.params.slug);
    }

    renderTags() {
        if (typeof this.props.post =='undefined'
            || typeof this.props.post.tags == 'undefined'
        ) {
            return '';
        }

        return this.props.post.tags.map(tag => {
            return (
                <Tag tag={tag} key={tag.id} />
            );
        });
    }

    renderImage() {
        if (typeof this.props.post =='undefined'
            || typeof this.props.post.featured_image == 'undefined'
        ) {
            return '';
        }
        return (
            <div className="text-center w-25 pr-3 float-left">
                <img className="mt-2" src={`http://admin.gkdemy.com${this.props.post.featured_image}`} alt="..." />
            </div>
        )
    }

    renderCategories() {
        if (typeof this.props.post =='undefined'
            || typeof this.props.post.category == 'undefined'
        ) {
            return '';
        }
        return this.props.post.category.map(category => {
            return (
                <Category category={category} key={category.category_id} />
            );
        });
    }

    render() {
        if (!this.props.post) {
            return <div>Loading...</div>;
        }
        if (typeof this.props.post === 'undefined'
            || this.props.post.length === 0
        ) {
            return '';
        }

        if (typeof this.props.post.post_desc != 'undefined') {
            var desc = Parser(this.props.post.post_desc);
        }
        return (
            <div className="row">
                <Meta />
                <div className="section p-0 pt-2">
                    <div className="">
                        <div className="">
                            <div className="col-md-12">
                                <h2 className="gk-post-title-heading">{this.props.post.post_title}</h2>
                                <p className="gk-post-date-time">
                                    <i className="material-icons">calendar_today</i>
                                    {this.props.post.publish_at} 
                                </p>
                            </div>

                            <div className="col-md-12 d-block">
                                {this.renderImage()}
                                <div className="gk-post-desc">
                                    <div className="font-size-16">
                                        {desc}
                                    </div>
                                    <div>
                                        {this.renderCategories()}
                                    </div>
                                    <div className="gap-xy-2 mt-2 mb-4">
                                        {this.renderTags()}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => {
    return { post: state.posts };
    // return { post: state.posts[ownProps.match.params.id] }
}

export default connect(
    mapStateToProps,
    { fetchPost }
)(Post);