import React from 'react';

const PostGrid = () => {
    return (
        <div className="col-md-4">
            <div className="card border hover-shadow-6 mb-6 d-block">
                <a href="#">
                    <img className="card-img-top" src="../assets/img/thumb/1.jpg" alt="Card image cap" />
                </a>
                <div className="p-6 text-center">
                    <p><a className="small-5 text-lighter text-uppercase ls-2 fw-400" href="#">News</a></p>
                    <h5 className="mb-0"><a className="text-dark" href="#">We relocated our office to a new designed garage</a></h5>
                </div>
            </div>
        </div>
    );
};

export default PostGrid;