import React from 'react';
import { Link } from 'react-router-dom';

const Tag = ({ tag }) => {
    return (
        <Link to={`/tag/${tag.tag_slug}`}  className="badge badge-pill badge-secondary">
            {tag.tag_name}
        </Link>
    );
};

export default Tag;