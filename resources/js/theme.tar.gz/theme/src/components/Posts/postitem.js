import React from 'react';
import { Link } from 'react-router-dom';
import Parser from 'html-react-parser';

const PostItem = ({ post }) => {
    if (typeof post == 'undefined' || !post) {
        return '';
    }
    var shortDesc = '';
    if (typeof post !='undefined'
        && post
        && typeof post.post_desc != 'undefined'
    ) {
        shortDesc = Parser((post.post_desc).substring(0, 150));
    }
    return (
        <div className="row gk-post-list">
            <div className="col-md-3 pr-0" style={{float: "left", width: "20%"}}>
                <a href="#">
                    <img width="190" className="fit-cover position-absolute h-100" src={`http://admin.gkdemy.com/${post.featured_image}`} alt="Card image cap" />
                </a>
            </div>
            <div className="col-md-9 gk-post-desc">
                <div className="p-2">
                    <h4 className="m-0 font-size-16 font-weight-500">{post.post_title}</h4>
                    <div className="m-0 font-size-14">{shortDesc}</div>
                    <Link to={`/current-affairs/${post.post_slug}`}  className="small ls-1">
                    Read More <span className="pl-1">⟶</span>
                    </Link>
                </div>
            </div>

        </div>
    );
}

export default PostItem;