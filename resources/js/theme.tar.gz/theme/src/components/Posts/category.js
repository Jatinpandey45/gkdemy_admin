import React from 'react';
import { Link } from 'react-router-dom';

const Category = ({ category }) => {
    var toParams = {
        'pathname': '/category/'+(category.category_slug),
        id: category.category_id
    };
    return (
        <Link to={toParams}  className="badge badge-pill badge-dark">
            {category.category_name}
        </Link>
    );
};

export default Category;