import React from 'react';
import {connect} from 'react-redux';
import { fetchPosts } from '../../actions';
import PostItem from './postitem';

class PostList extends React.Component {
    componentDidMount() {
        this.props.fetchPosts();
    }

    renderList() {
        if (!this.props.posts) {
            return <div>Loading...</div>;
        }
        if (typeof this.props.posts == 'undefined'
            || this.props.posts.length == 0
        ) {
            return '';
        }

        var posts = this.props.posts;
        posts = Array.from(posts);
        return posts.map((post) => {
            return (
                <div className="card hover-shadow-3 my-2" key={post.id}>
                    <PostItem post={post} />
                </div>
            );
        });
    }

    render() {
        return (
            <div>
                {this.renderList()}
            </div>
        );
    }
};


const mapStateToProps = state => {
    return { posts : state.posts };
}

export default connect(mapStateToProps, { fetchPosts })(PostList);