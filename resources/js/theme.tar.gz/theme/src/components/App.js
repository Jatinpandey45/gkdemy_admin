import React from 'react';
import Nav from './NavBar/Nav';
import Main from './Content/main';
import Header from './Header/header';
import { Router } from 'react-router-dom';

import history from '../history';

import '../App.css';

import '../assets/css/page.css';
import '../css/style.css';

const App = () => {
  return (
    <Router history={history}>
      <div>
          <Nav />
          <Header />
          <Main />
      </div>
    </Router>
  );
}

export default App;
